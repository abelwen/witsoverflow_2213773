package com.example.witsoverflow;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SignIn extends AppCompatActivity {
    Button Sign_in;
    EditText email,password;
    TextView reset_p,signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);
        Sign_in = findViewById(R.id.b_signin);
        email = findViewById(R.id.editText_email);
        password = findViewById(R.id.editText_password);
        reset_p = findViewById(R.id.resetPassword);
        signup = findViewById(R.id.Text_signup);
        Sign_in.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkUserData();
            }
        });
    }
    void checkUserData(){
        Boolean isValid = true;
        if(isEmpty(email)){
            email.setError("Enter your email to log in!");
            isValid = false;
        }
        else {
            if (!isEmail(email)) {
                email.setError("Enter valid email!");
                isValid = false;
            }
        }
        if(isEmpty(password)){
            password.setError("Enter your password to log in!");
            isValid = false;
        }
        else {
            if (password.getText().toString().length()<4) {
                password.setError("Password must be at least 4 charactors long!");
                isValid = false;
            }
        }
        if(isValid){
            String Email = email.getText().toString();
            String Password = password.getText().toString();
            if(Email.equals("tristan@gmail.com")&& Password.equals("9Baker")){
                Toast.makeText(getApplicationContext(),
                        "Redirecting...",Toast.LENGTH_SHORT).show();
                Intent switchActivityIntent = new Intent(getApplicationContext(),ProfileUI.class);
                startActivity(switchActivityIntent);
            }
            else {
                Toast.makeText(getApplicationContext(),
                        "Wrong password or email address",Toast.LENGTH_SHORT).show();
            }
        }
    }
    boolean isEmail(EditText text) {
        CharSequence email = text.getText().toString();
        return (!TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches());
    }

    boolean isEmpty(EditText text) {
        CharSequence str = text.getText().toString();
        return TextUtils.isEmpty(str);
    }
}